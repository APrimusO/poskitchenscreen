## Module <pos_kitchen_screen_odoo>

#### 02.05.2023
#### Version 16.0.1.0.0
#### ADD
- Initial commit for Pos Kitchen Screen
